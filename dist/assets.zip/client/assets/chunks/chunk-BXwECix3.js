const _={"toggle-container":"_toggle-container_1cpwr_1",toggle:"_toggle_1cpwr_1",slider:"_slider_1cpwr_34",light:"_light_1cpwr_54",labels:"_labels_1cpwr_146",equal:"_equal_1cpwr_220"};export{_ as s};
//# sourceMappingURL=chunk-BXwECix3.js.map
