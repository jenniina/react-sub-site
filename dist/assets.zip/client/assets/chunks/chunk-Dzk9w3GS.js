const t={light:"_light_gm0xt_1"};export{t as s};
//# sourceMappingURL=chunk-Dzk9w3GS.js.map
