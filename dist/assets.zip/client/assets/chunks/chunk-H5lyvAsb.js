const _={colortextwrap:"_colortextwrap_1xckx_1",section:"_section_1xckx_13",light:"_light_1xckx_87","color-ul":"_color-ul_1xckx_679",shape:"_shape_1xckx_683"};export{_ as s};
//# sourceMappingURL=chunk-H5lyvAsb.js.map
