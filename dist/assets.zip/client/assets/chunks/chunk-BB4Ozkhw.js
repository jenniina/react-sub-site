const _={list:"_list_5h9hd_1",subheading:"_subheading_5h9hd_13",light:"_light_5h9hd_28",welcome:"_welcome_5h9hd_28","li-about":"_li-about_5h9hd_70",language:"_language_5h9hd_114",newest:"_newest_5h9hd_143",extras:"_extras_5h9hd_147",first:"_first_5h9hd_172","language-welcome":"_language-welcome_5h9hd_229"};export{_ as s};
//# sourceMappingURL=chunk-BB4Ozkhw.js.map
