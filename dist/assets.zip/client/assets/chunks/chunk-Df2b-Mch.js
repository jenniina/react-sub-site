const _={"edit-user":"_edit-user_1bm61_1",language:"_language_1bm61_11",p:"_p_1bm61_18","p-last":"_p-last_1bm61_22"};export{_ as s};
//# sourceMappingURL=chunk-Df2b-Mch.js.map
