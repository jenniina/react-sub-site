const _={confirm:"_confirm_2cm1x_1",content:"_content_2cm1x_16",buttons:"_buttons_2cm1x_30","confirm-btn":"_confirm-btn_2cm1x_45","cancel-btn":"_cancel-btn_2cm1x_53",message:"_message_2cm1x_60"};export{_ as s};
//# sourceMappingURL=chunk-CkHyhkQS.js.map
