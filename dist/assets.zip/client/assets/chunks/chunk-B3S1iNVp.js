function t(t){return({dispatch:a,getState:e})=>n=>o=>"function"==typeof o?o(a,e,t):n(o)}var a=t(),e=t;export{a as t,e as w};
//# sourceMappingURL=chunk-B3S1iNVp.js.map
