const e={editform:"_editform_1ls0s_1","delete-account":"_delete-account_1ls0s_7"};export{e as s};
//# sourceMappingURL=chunk-DuaX-nPs.js.map
